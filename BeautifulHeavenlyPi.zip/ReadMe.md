## Tic-Tac-Toe

**Gibson Gossett**

**5/26/21**

This is the Tie-Tac-Toe game I have created. This is for two people to play. 

My motivation for making  and the reason why I chose this was the idea to make a fun game for friends to play and compete against eachother.  With Tie-Tac-Toe users can easily learn the game find a way to have fun and play with friends.

What I have learned while making this was how to implement games into a GUI. I have also learned how to build my first user vs user game.

**How to Use**

1. "RUN"
2. Type the name of the first player where instructed on console.
3. Type the name of the second player where instructed on console.
4. Read the welcome letter.
5. First player selects the square of choice.
6. Next player's turn.
7. Continue.
8. Once a person has got three in a row it shall be highlighted and game over.
9. Click close to end and run to play again.
10. Have fun.